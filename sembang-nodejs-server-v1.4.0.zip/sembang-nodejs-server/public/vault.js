import { createIdentity, recoverIdentity, fingerprint } from './crypto.js';
const database = () => new Promise((resolve, reject) => {
  const req = indexedDB.open('sembang-e2ee-v1', 1);
  req.onupgradeneeded = () => req.result.createObjectStore('keys');
  req.onerror = () => reject(new Error('Storan kunci pelayar tidak tersedia. Gunakan pelayar biasa dan benarkan storan laman.'));
  req.onsuccess = () => resolve(req.result);
});
export async function stored(key, value) {
  const db = await database();
  try { return await new Promise((resolve, reject) => {
    const tx = db.transaction('keys', value === undefined ? 'readonly' : 'readwrite');
    const req = value === undefined ? tx.objectStore('keys').get(key) : tx.objectStore('keys').put(value, key);
    let result; req.onsuccess = () => { result = req.result; };
    tx.oncomplete = () => resolve(result); tx.onerror = tx.onabort = () => reject(tx.error || new Error('Kunci gagal disimpan.'));
  }); } finally { db.close(); }
}
export async function unlockIdentity(user, password, api) {
  if (!crypto.subtle || !window.isSecureContext) throw new Error('Penyulitan memerlukan HTTPS atau localhost.');
  const storageKey = `identity:${user.id}`;
  const remote = await api('/identity');
  const local = await stored(storageKey);
  if (local && remote) {
    if (local.record.fingerprint !== remote.fingerprint || await fingerprint(remote.publicKey) !== remote.fingerprint) throw new Error('Kunci akaun berubah. Akses disekat untuk melindungi chat.');
    return local;
  }
  if (remote) {
    if (!password) throw new Error('Log masuk semula untuk membuka kunci chat pada peranti ini.');
    const identity = await recoverIdentity(remote, password);
    await stored(storageKey, identity); return identity;
  }
  if (!password) throw new Error('Log masuk semula untuk menyediakan kunci chat pada peranti ini.');
  const generated = await createIdentity(password);
  try { await api('/identity', { method: 'POST', body: generated.record }); }
  catch (e) { if (e.status !== 409) throw e; return unlockIdentity(user, password, api); }
  const identity = { privateKey: generated.privateKey, record: generated.record };
  await stored(storageKey, identity);
  return identity;
}
export async function pinPeer(myId, peerId, record) {
  if (!record || await fingerprint(record.publicKey) !== record.fingerprint) throw new Error('Kunci penyulitan kenalan tidak sah.');
  const key = `pin:${myId}:${peerId}`;
  const db = await database();
  try { await new Promise((resolve, reject) => {
    const tx = db.transaction('keys', 'readwrite'), store = tx.objectStore('keys');
    const req = store.get(key);
    let changed = false;
    req.onsuccess = () => {
      if (req.result && req.result !== record.fingerprint) { changed = true; tx.abort(); }
      else if (!req.result) store.put(record.fingerprint, key);
    };
    tx.oncomplete = resolve;
    tx.onabort = tx.onerror = () => reject(new Error(changed ? 'Kunci kenalan berubah. Penghantaran disekat; semak nombor keselamatan.' : 'Kunci kenalan gagal disimpan.'));
  }); } finally { db.close(); }
}
